calculate\_cost module
======================

.. automodule:: calculate_cost
   :members:
   :undoc-members:
   :show-inheritance:

check\_python\_version module
=============================

.. automodule:: check_python_version
   :members:
   :undoc-members:
   :show-inheritance:

create\_diag\_table\_file module
================================

.. automodule:: create_diag_table_file
   :members:
   :undoc-members:
   :show-inheritance:

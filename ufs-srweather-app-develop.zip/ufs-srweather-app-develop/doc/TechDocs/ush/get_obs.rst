get\_obs module
===============

.. automodule:: get_obs
   :members:
   :undoc-members:
   :show-inheritance:

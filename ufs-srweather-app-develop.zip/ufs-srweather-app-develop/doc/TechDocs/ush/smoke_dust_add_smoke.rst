smoke\_dust\_add\_smoke module
==============================

.. automodule:: smoke_dust_add_smoke
   :members:
   :undoc-members:
   :show-inheritance:

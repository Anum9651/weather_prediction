smoke\_dust\_generate\_fire\_emissions module
=============================================

.. automodule:: smoke_dust_generate_fire_emissions
   :members:
   :undoc-members:
   :show-inheritance:

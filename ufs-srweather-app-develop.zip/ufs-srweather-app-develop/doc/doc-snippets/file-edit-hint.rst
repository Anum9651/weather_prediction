.. Hint:: 
   
   To open the configuration file in the command line, users may run the command:

   .. code-block:: console

      vi config.yaml

   To modify the file, hit the ``i`` key and then make any changes required. To close and save, hit the ``esc`` key and type ``:wq`` to write the changes to the file and exit/quit the file. Users may opt to use their preferred code editor instead.
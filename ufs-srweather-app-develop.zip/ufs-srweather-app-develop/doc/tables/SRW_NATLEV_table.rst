:orphan:

************************************************************
Fields Requested in the UPP Parameter Table for SRW NATLEV
************************************************************

Field description (column 1), level type as defined by WMO (column 2), abbreviated names
as they appear in the Grib2 output file (column 3), and number of levels output (column 4).

.. csv-table::
   :file: SRW_NATLEV_table.csv
   :widths: 9, 40, 30, 15, 10
   :header-rows: 1

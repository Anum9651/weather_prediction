Invalid or corrupted git repository (.git dir exists, but is empty) for error
testing.
 

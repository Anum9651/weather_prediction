unload("python")
unload("miniconda3")

load("conda")
setenv("SRW_ENV", "srw_app")

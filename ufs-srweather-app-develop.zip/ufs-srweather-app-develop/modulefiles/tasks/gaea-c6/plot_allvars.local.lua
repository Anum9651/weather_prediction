unload("python")
load("conda")

setenv("SRW_GRAPHICS_ENV", "srw_graphics")

load("python_srw")

load(pathJoin("netcdf", os.getenv("netcdf_ver")))

